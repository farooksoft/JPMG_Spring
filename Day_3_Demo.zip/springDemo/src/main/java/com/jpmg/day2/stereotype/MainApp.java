package com.jpmg.day2.stereotype;

import com.jpmg.day2.stereotype.controller.EmployeeController;
import com.jpmg.day2.stereotype.manager.EmployeeManager;
import com.jpmg.day2.stereotype.ManagerImpl.EmployeeManagerImpl;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class MainApp {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");

//        EmployeeManager manager = context.getBean(EmployeeManager.class);
//        EmployeeManagerImpl manager1 = context.getBean(EmployeeManagerImpl.class);
        //System.out.println(manager1.createNewEmployee());

        EmployeeController controller = (EmployeeController) context.getBean("employeeController");
        System.out.println(controller.createNewEmployee());

    }
}
