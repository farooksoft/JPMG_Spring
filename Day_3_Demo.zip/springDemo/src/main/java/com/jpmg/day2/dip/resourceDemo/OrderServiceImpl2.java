package com.jpmg.day2.dip.resourceDemo;

public class OrderServiceImpl2 implements OrderService{
    @Override
    public String getOrderDetails(String orderId) {
        return "Order Details from impl 2, for order ID = " + orderId;
    }
}
