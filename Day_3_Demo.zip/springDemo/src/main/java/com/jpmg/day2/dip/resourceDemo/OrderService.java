package com.jpmg.day2.dip.resourceDemo;

public interface OrderService {
    String getOrderDetails(String orderId);
}
