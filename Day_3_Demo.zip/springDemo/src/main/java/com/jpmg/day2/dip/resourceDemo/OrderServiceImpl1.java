package com.jpmg.day2.dip.resourceDemo;

public class OrderServiceImpl1 implements OrderService{
    @Override
    public String getOrderDetails(String orderId) {
        return "Order Details from impl 1, for order ID = " + orderId;
    }
}
