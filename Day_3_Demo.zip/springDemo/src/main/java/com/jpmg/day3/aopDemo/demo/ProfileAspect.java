package com.jpmg.day3.aopDemo.demo;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.core.Ordered;
import org.springframework.stereotype.Component;

import java.lang.reflect.Method;

@Component
@Aspect
public class ProfileAspect implements Ordered {
    @Around(value = "@annotation(profile)", argNames = "profile")
    public Object invoke(final ProceedingJoinPoint pjp, final Profile profile) throws Throwable{
        Object target = pjp.getTarget();
        MethodSignature signature = (MethodSignature) pjp.getSignature();
        Method method = signature.getMethod();

        long nanoTimestart = System.nanoTime();

        Object result = pjp.proceed(); //execute the method
        long nanoFinishTime = System.nanoTime();

        System.out.println("Completed" + method.getName()+ " on " +target.getClass() + " in " + (nanoFinishTime-nanoTimestart)+ "nano Seconds");
        return result;
    }

    @Override
    public int getOrder() {
        return 0;
    }
}
