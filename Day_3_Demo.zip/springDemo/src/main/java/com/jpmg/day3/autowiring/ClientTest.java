package com.jpmg.day3.autowiring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class ClientTest {
    public static void main(String[] args) {
        ApplicationContext applicationContext = null;

        try{
            applicationContext = new ClassPathXmlApplicationContext("Beans.xml");

            Employee employee = (Employee) applicationContext.getBean("employee");
            System.out.println(employee);

            Address address = employee.getAddress();
            System.out.println(address);
        }catch (Exception e){
            e.printStackTrace();
        }finally {
            if(applicationContext !=null){
                ((AbstractApplicationContext)applicationContext).close();
            }
        }
    }
}
