package com.jpmg.day3.annotations;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
        AbstractApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");

//        Student student = (Student) context.getBean("student");
//        System.out.println("Name: "+ student.getName());
//        System.out.println("Age: "+ student.getAge());
//        Profile profile = (Profile) context.getBean("profile");
//        profile.printName();
//        profile.printAge();

        HelloWorld helloWorld = (HelloWorld) context.getBean("helloWorld");
        helloWorld.getMessage();
        context.registerShutdownHook();

    }
}
