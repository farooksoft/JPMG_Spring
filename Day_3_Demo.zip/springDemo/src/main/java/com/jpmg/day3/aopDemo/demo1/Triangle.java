package com.jpmg.day3.aopDemo.demo1;

import org.springframework.stereotype.Component;

@Component
public class Triangle {

    private String name = "Triangle";
    @Loggable
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
