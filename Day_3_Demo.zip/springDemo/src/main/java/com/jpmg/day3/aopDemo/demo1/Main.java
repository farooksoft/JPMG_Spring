package com.jpmg.day3.aopDemo.demo1;

import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {
    public static void main(String[] args) {
        ApplicationContext context = new AnnotationConfigApplicationContext(ConfigClass.class);
        ShapeService shapeService = context.getBean("shapeService", ShapeService.class);
        shapeService.getCircle().getName();

    }
}
