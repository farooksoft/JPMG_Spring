package com.jpmg.day3.autowiring;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class AutoWireName {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext(new String[]{"Beans.xml"});
        EmployeeBean employeeBean = (EmployeeBean) context.getBean("employee");
        System.out.println(employeeBean.getFullName());
        System.out.println(employeeBean.getDepartmentBean().getName());
    }
}
