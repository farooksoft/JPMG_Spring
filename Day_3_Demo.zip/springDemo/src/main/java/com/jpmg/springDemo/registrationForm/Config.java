package com.jpmg.springDemo.registrationForm;

import com.jpmg.springDemo.registrationForm.bean.UserRegistrationBean;
import com.jpmg.springDemo.registrationForm.bean.UserRegistrationBeanImpl;
import com.jpmg.springDemo.registrationForm.bean.UserRegistrationValidator;
import com.jpmg.springDemo.registrationForm.service.RegistrationService;
import com.jpmg.springDemo.registrationForm.service.RegistrationServiceImpl;
import org.springframework.beans.factory.config.ConfigurableBeanFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Scope;

public class Config {
    @Bean
    public UserRegistrationValidator validator(){
        return new UserRegistrationValidator();
    }

    @Bean
    public RegistrationService registrationService(){
        return new RegistrationServiceImpl();
    }

    @Scope(ConfigurableBeanFactory.SCOPE_PROTOTYPE)
    @Bean
    public UserRegistrationBean userRegistrationBean(){
        return new UserRegistrationBeanImpl();
    }
}
