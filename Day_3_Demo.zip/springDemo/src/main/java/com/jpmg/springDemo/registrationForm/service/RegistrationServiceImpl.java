package com.jpmg.springDemo.registrationForm.service;

public class RegistrationServiceImpl  implements RegistrationService {
    @Override
    public void register(UserInfo userInfo) {

    }
}
