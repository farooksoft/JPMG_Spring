package com.jpmg.springDemo;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

@Configurable
@ComponentScan({"com.jpmg.springDemo"})
public class ConstructorBasedDI {
    @Bean
    public OrderService orderService(){
        return new OrderService();
    }

    @Bean
    public OrderServiceClient OrderServiceClient(){
        return new OrderServiceClient(orderService());
    }

    private static class OrderServiceClient{
        private OrderService orderService;

        OrderServiceClient(OrderService orderService){
            this.orderService = orderService;
        }

        public void showPendingOrderDetails(){
            System.out.println(orderService.getOrderDetails("260"));
        }
    }

    public static void main(String[] args) {
        AnnotationConfigApplicationContext configApplicationContext = new AnnotationConfigApplicationContext(ConstructorBasedDI.class);
        OrderServiceClient bean = configApplicationContext.getBean(OrderServiceClient.class);
        bean.showPendingOrderDetails();
    }

}
