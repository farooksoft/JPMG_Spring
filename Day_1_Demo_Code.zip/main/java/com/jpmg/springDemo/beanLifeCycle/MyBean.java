package com.jpmg.springDemo.beanLifeCycle;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

//public class MyBean implements InitializingBean, DisposableBean {
public class MyBean {
    private OtherBean otherBean;

    public MyBean() {
        System.out.println("My bean constructor");
    }

    @PostConstruct
    public void myPostConstruct(){
        System.out.println("@Post Construct");
    }
//    @Override
//    public void afterPropertiesSet() throws Exception {
//        System.out.println("My post Constructor");
//    }

    @Autowired
    public void setOtherBean(OtherBean otherBean){
        System.out.println("SetOtherBean():" + otherBean);
        this.otherBean = otherBean;
    }
    public void doSomething(){
        System.out.println("do Something");
    }

    @PreDestroy
    public void cleanUp(){
        System.out.println("@PreDestroy");
    }

//    @Override
//    public void destroy() throws Exception {
//        System.out.println("clean up method");
//    }
}
