package com.jpmg.springDemo.beanLifeCycle;

import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class LifeCycleDemo {
    @Bean
    public MyBean myBean(){
        return new MyBean();
    }

    @Bean
    public OtherBean otherBean(){
        return new OtherBean("Its hi form Other Bean....");
    }

    public static void main(String[] args) {
        ConfigurableApplicationContext context = new AnnotationConfigApplicationContext(LifeCycleDemo.class);
        context.registerShutdownHook();

        System.out.println("--- accessing bean ----");
        MyBean bean = context.getBean(MyBean.class);
        bean.doSomething();

        System.out.println("--- finished ----");
    }

}
