package com.jpmg.customerBackEnd.controller;

import com.jpmg.customerBackEnd.model.Customer;
import com.jpmg.customerBackEnd.repository.CustomerRepository;
import com.jpmg.customerBackEnd.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/customer")
public class CustomerController {
    @Autowired
    CustomerService customerService;

    @GetMapping
    public ResponseEntity<List<Customer>> listAllCustomers() {

        return new ResponseEntity<List<Customer>>(customerService.list(), HttpStatus.OK);

    }

    /*
     * Create a new user
     */

    @PostMapping
    public ResponseEntity<Customer> createCustomer(@RequestBody Customer customer) {
       customerService.save(customer);
        return new ResponseEntity<Customer>(customer, HttpStatus.CREATED);
    }

}
