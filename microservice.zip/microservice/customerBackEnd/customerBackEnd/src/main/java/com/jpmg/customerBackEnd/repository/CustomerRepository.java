package com.jpmg.customerBackEnd.repository;

import com.jpmg.customerBackEnd.model.Customer;
import org.springframework.data.repository.CrudRepository;

public interface CustomerRepository extends CrudRepository<Customer, Long> {
}
