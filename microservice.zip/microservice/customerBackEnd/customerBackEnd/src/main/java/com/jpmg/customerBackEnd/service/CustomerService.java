package com.jpmg.customerBackEnd.service;

import com.jpmg.customerBackEnd.model.Customer;

import java.util.List;

public interface CustomerService {
    public void save(Customer customer);
    public List<Customer> list();
}
