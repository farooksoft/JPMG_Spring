package com.jpmg.customerBackEnd.service;

import com.jpmg.customerBackEnd.model.Customer;
import com.jpmg.customerBackEnd.repository.CustomerRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CustomerServiceImpl implements CustomerService{
    @Autowired
    private CustomerRepository customerRepository;

    @Override
    public void save(Customer customer) {
        customerRepository.save(customer);
    }

    @Override
    public List<Customer> list() {
        return (List<Customer>) customerRepository.findAll();
    }

}
