package com.cloudgatewayservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CloudGatewayServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
