package com.jpmg.productBackEnd.repository;

import com.jpmg.productBackEnd.model.Products;
import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<Products,Long> {
}
