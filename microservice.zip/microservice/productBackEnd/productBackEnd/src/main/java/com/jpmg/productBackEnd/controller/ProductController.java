package com.jpmg.productBackEnd.controller;

import com.jpmg.productBackEnd.model.Products;
import com.jpmg.productBackEnd.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("api/product")
public class ProductController {
    @Autowired
    ProductService productService;

    @GetMapping
    public ResponseEntity<List<Products>> listAllProducts() {
        return new ResponseEntity<>(productService.list(), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Products> createProduct(@RequestBody Products product) {
        productService.save(product);
        return new ResponseEntity<Products>(product, HttpStatus.CREATED);
    }
}
