package com.jpmg.productBackEnd.service;

import com.jpmg.productBackEnd.model.Products;

import java.util.List;

public interface ProductService {
    public void save(Products products);

    public List<Products> list();
}
