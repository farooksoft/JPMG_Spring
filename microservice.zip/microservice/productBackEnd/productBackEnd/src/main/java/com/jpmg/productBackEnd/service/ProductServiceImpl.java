package com.jpmg.productBackEnd.service;

import com.jpmg.productBackEnd.model.Products;
import com.jpmg.productBackEnd.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService{
    @Autowired
    ProductRepository productRepository;

    @Override
    public void save(Products products) {
        productRepository.save(products);
    }

    @Override
    public List<Products> list() {
        return (List<Products>) productRepository.findAll();
    }
}
