package com.spg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpgApplicationTests {

	@Test
	void contextLoads() {
	}

}
