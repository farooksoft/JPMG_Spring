package com.jpmg.rest.validation.repository;

import com.jpmg.rest.validation.model.User;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRepository extends JpaRepository<User,Long> {
}
