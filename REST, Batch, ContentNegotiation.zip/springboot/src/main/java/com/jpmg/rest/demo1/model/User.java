package com.jpmg.rest.demo1.model;

public class User {
    @NotEmpty(message = "Name can not empty")
    String name;
    String lastName;
    @NotEmpty(message = "Email can not empty")
    @Email
    String email;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
}
