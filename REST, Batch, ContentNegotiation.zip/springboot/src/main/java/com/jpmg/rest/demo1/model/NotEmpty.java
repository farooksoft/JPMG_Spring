package com.jpmg.rest.demo1.model;

public @interface NotEmpty {
    String message();
}
