package com.jpmg.rest.demo1.controller;

import com.jpmg.rest.demo1.model.User;
import org.springframework.web.bind.annotation.*;

@RestController
public class UserController {
    @GetMapping("/user")
    public User getUser(@RequestParam(value = "name", defaultValue = "david") String name,
                        @RequestParam(value = "lastName", defaultValue = "mark") String lastName,
                        @RequestParam(value = "email", defaultValue = "david@gmail.com") String email) {
        User user = new User();
        user.setName(name);
        user.setLastName(lastName);
        user.setEmail(email);
        return user;
    }

    @PostMapping("/user")
    public User postUser(@RequestBody User user) {
        return user;
    }
}
