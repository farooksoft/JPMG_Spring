package com.jpmg.rest.demo1.model;

public @interface Email {
}
