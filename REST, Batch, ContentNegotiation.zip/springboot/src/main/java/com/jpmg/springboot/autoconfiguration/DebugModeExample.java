package com.jpmg.springboot.autoconfiguration;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;

@EnableAutoConfiguration(exclude = {JmxAutoConfiguration.class})
public class DebugModeExample {

    public static void main (String[] args) {
        //just doing programmatically for demo
        //String[] appArgs = {"--debug"};
        //System.setProperty("debug", "");
        //String[] appArgs = {"--debug", "--spring.jmx.enabled=false"};
        String[] appArgs = {"--debug", "--spring.autoconfigure.exclude=org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration"};

        SpringApplication app = new SpringApplication(DebugModeExample.class);
        app.setBannerMode(Banner.Mode.OFF);
        app.setLogStartupInfo(false);
        ConfigurableApplicationContext c = app.run(appArgs);
    }
}
