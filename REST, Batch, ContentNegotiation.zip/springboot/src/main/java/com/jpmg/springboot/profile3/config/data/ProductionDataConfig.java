package com.jpmg.springboot.profile3.config.data;

import com.jpmg.springboot.profile3.bean.Data;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Profile("production")
@Configuration
public class ProductionDataConfig implements DataConfig  {
    @Override
    @Bean
    public Data getData() {
        return new Data("Data Configuration for Production Purpose");
    }
}
