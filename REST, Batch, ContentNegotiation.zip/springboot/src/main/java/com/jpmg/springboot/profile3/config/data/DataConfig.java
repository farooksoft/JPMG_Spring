package com.jpmg.springboot.profile3.config.data;

import com.jpmg.springboot.profile3.bean.Data;

public interface DataConfig {
        Data getData();
}
