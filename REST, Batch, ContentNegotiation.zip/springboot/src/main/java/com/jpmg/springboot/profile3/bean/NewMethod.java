package com.jpmg.springboot.profile3.bean;

public class NewMethod {
    private String config;

    public NewMethod(String config) {
        this.config = config;
    }

    public String getConfig() {
        return config;
    }

    public void setConfig(String config) {
        this.config = config;
    }
}
