package com.jpmg.springboot.crud.repository;

import com.jpmg.springboot.crud.model.Data;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface DataRepository extends JpaRepository<Data, Long> {
    List<Data> findByPublished(boolean published);
    List<Data> findByTitleContaining(String title);
}
