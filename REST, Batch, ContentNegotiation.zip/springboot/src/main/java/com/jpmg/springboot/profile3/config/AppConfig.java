package com.jpmg.springboot.profile3.config;

import com.jpmg.springboot.profile3.bean.Data;
import com.jpmg.springboot.profile3.bean.Method;
import com.jpmg.springboot.profile3.bean.NewMethod;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;

@Configuration
@ComponentScan(basePackages = "com.jpmg.springboot.profile3")
public class AppConfig {
    @Autowired
    Data data;

    @Bean
    @Profile("development")
    public Method getDevelopmentMethod() {
        return new Method("Method Level for Development Purpose");
    }

    @Bean
    @Profile("production")
    public Method getProdutionMethod() {
        return new Method("Method Level for Production Purpose");
    }

    @Bean
    @Profile("addition")
    public NewMethod getAdditionMethod() {
        return new NewMethod("Method Level for Addition Purpose");
    }
}
