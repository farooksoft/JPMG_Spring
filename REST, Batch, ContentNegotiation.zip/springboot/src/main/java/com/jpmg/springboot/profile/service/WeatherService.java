package com.jpmg.springboot.profile.service;

public interface WeatherService {
    String forecast();
}
