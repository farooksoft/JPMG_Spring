package com.jpmg.springboot.profile3;

import com.jpmg.springboot.profile3.bean.Data;
import com.jpmg.springboot.profile3.bean.Method;
import com.jpmg.springboot.profile3.bean.NewMethod;
import com.jpmg.springboot.profile3.config.AppConfig;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.core.env.AbstractEnvironment;

public class MainApp {
    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();

        //context.getEnvironment().setActiveProfiles("production", "addition");
        context.getEnvironment().setActiveProfiles("production","addition");

        context.register(AppConfig.class);
        context.refresh();

//		System.setProperty(AbstractEnvironment.ACTIVE_PROFILES_PROPERTY_NAME, "production");
//		AbstractApplicationContext context = new AnnotationConfigApplicationContext(AppConfig.class);

        Data data = context.getBean(Data.class);
        System.out.println(data.getConfig());

        Method method = context.getBean(Method.class);
        System.out.println(method.getConfig());

        // for @Profile("addition")
        NewMethod newMethod = context.getBean(NewMethod.class);
        System.out.println(newMethod.getConfig());

        context.close();
    }
}
