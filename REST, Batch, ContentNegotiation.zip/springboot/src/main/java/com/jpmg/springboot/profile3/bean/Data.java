package com.jpmg.springboot.profile3.bean;

public class Data {
    private String config;

    public Data() {
    }

    public Data(String config) {
        this.config = config;
    }

    public String getConfig() {
        return config;
    }

    public void setConfig(String config) {
        this.config = config;
    }
}
