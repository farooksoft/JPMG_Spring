package com.sleuthDemo;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.client.RestTemplate;
import zipkin.server.EnableZipkinServer;


@SpringBootApplication
@EnableZipkinServer
public class SleuthDemoApplication {
	private static final Logger LOG =  LoggerFactory.getLogger(SleuthDemoApplication.class);

	@Autowired
	private RestTemplate restTemplate;

	@Bean
    public RestTemplate template() {
        return new RestTemplate();
    }

	@GetMapping("/check")
	public String check() {
		LOG.info("check service called....");
		return "The api executed successfully";
	}


	public static void main(String[] args) {
		SpringApplication.run(SleuthDemoApplication.class, args);
	}

}
