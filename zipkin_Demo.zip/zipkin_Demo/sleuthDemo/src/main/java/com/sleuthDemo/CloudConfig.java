//package com.sleuthDemo;
//
//import brave.sampler.Sampler;
//import org.springframework.cloud.sleuth.sampler.*;
//import org.springframework.context.annotation.Bean;
//import org.springframework.web.client.RestTemplate;
//
//public class CloudConfig {
//
//    @Bean
//    public RestTemplate template() {
//        return new RestTemplate();
//    }
//    @Bean
//    public AlwaysSampler defaultSampler() {
//        return new AlwaysSampler();
//    }
//}
