package com.zipkinDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZipkinDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
