package com.zipkinserver1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZipkinServer1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
