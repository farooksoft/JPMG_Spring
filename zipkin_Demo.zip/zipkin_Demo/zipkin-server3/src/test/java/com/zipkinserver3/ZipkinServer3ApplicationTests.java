package com.zipkinserver3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZipkinServer3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
