package com.day5.springDAO;

public interface EmployeeDao {
    void save(Employee employee);
}
