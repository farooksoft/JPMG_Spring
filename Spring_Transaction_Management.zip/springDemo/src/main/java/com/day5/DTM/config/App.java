package com.day5.DTM.config;

import com.day5.DTM.model.Address;
import com.day5.DTM.model.Employees;
import com.day5.DTM.service.EmployeeService;
import com.day5.DTM.serviceImpl.EmployeeServiceImpl;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class App {
    public static void main(String[] args) {
        ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("appContext.xml");

        EmployeeService employeeService = context.getBean("employeeServiceImpl", EmployeeServiceImpl.class);

        employeeService.addEmployees(createEmployee());
        context.registerShutdownHook();
    }

    private static Employees createEmployee() {
        Employees employees = new Employees();
        Address address = new Address();
        employees.setId(123);
        employees.setName("John");
        employees.setAge(25);

        //same as employee ID
        address.setId(employees.getId());
        address.setAddrLine("hunters Line");
        address.setCity("mumbai");
        employees.setAddress(address);

        return employees;
    }
}
