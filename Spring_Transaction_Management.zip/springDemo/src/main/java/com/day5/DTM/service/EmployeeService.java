package com.day5.DTM.service;

import com.day5.DTM.model.Employees;

public interface EmployeeService {
    public Employees getEmployees(int id);
    public void addEmployees(Employees employees);
}
