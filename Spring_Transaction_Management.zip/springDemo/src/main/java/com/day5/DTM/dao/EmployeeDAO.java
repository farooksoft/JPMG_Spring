package com.day5.DTM.dao;

import com.day5.DTM.model.Employees;
import com.day5.springDAO.Employee;

public interface EmployeeDAO {
    public void insertEmployee(Employees employee);
    public Employees findEmployee(int id);
}
