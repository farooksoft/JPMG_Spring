package com.day5.PTM;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.transaction.TransactionStatus;
import org.springframework.transaction.support.TransactionCallback;
import org.springframework.transaction.support.TransactionTemplate;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerDAO {
    private JdbcTemplate jdbcTemplate;
    private TransactionTemplate transactionTemplate;

    //create a table
    public void createTable(){
        String query = "create table Customer_Account( id int, name varchar(40), amount int, age int)";
        jdbcTemplate.execute(query);
    }

    //getter for TransactionTemplate
    public TransactionTemplate getTransactionTemplate(){
        return transactionTemplate;
    }

    //setter for TransactionTemplate

    public void setTransactionTemplate(TransactionTemplate transactionTemplate) {
        this.transactionTemplate = transactionTemplate;
    }
    //getter and setter for JDBC Template
    public JdbcTemplate getJdbcTemplate() {
        return jdbcTemplate;
    }

    public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    //Addind the customer
    public void addCustomer(int id, String name, int amount, int age){
        String query = "insert into Customer_Account value ("+id+", '"+name+"', "+amount+", "+age+")";
        jdbcTemplate.execute(query);
    }

    //deleting the customer
    public void deleteCustomer(int id){
        String query = ("delete from Customer_Account where id = " +id);
        jdbcTemplate.execute(query);
    }

    //extracting a count of all the customers
    public int countCustomer(){
        String query = "select count(*) from Customer_Account";
        return jdbcTemplate.queryForObject(query, Integer.class);
    }

    //getting the list of Customers from DB
    public List<Customer_Account> getAllCustomer(){
        String query = "select * from Customer_Account";
        return jdbcTemplate.query(query, new ResultSetExtractor<List<Customer_Account>>() {
            @Override
            public List<Customer_Account> extractData(ResultSet resultSet) throws SQLException, DataAccessException {
                List<Customer_Account> customers  = new ArrayList<Customer_Account>();
                while (resultSet.next()){
                    Customer_Account customer_account = new Customer_Account();
                    customer_account.setId(resultSet.getInt("id"));
                    customer_account.setName(resultSet.getString("name"));
                    customer_account.setAmount(resultSet.getInt("amount"));
                    customer_account.setAge(resultSet.getInt("age"));
                }
                return customers;
            }
        });
    }

    public void depositAmount(int id, int amount){
        transactionTemplate.execute(new TransactionCallback<Object>() {
            @Override
            public Object doInTransaction(TransactionStatus transactionStatus) {
                try{
                    getJdbcTemplate().update("update Customer_Account set amount = amount + ? where id = ?, amount, id");
                }catch (Exception e){
                    transactionStatus.isRollbackOnly();
                }
                return null;
            }
        });
    }

    public void withdrawAmount(int id, int amount){
        transactionTemplate.execute(new TransactionCallback<Object>() {
            @Override
            public Object doInTransaction(TransactionStatus transactionStatus) {
                try{
                    getJdbcTemplate().update("update Customer_Account set amount = amount - ? where id = ?, amount, id");
                }catch (Exception e){
                    transactionStatus.isRollbackOnly();
                }
                return null;
            }
        });
    }
}
