package com.jpmg.day3.aopDemo.demo2;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class EmployeeAspectPointcut {
    @Before("getNamePointcut()")
    public void loggingAdvice(){
        System.out.println("Executing the loggingAdvice on getName()");
    }
    @Before("getNamePointcut()")
    public void secondAdvice(){
        System.out.println("Executing the secondAdvice on getName()");
    }

    @Pointcut("execution(public String getName())")
    public void getNamePointcut(){}

    @Before("allMethodsPointcut()")
    public void allServiceMethodsAdvice(){
        System.out.println("Before Executing the Service Method");
    }

    @Pointcut("within(com.jpmg.day3.aopDemo.demo2.*)")
    public void allMethodsPointcut(){}


}
