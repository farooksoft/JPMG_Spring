package com.jpmg.day3.aopDemo.demo;

import org.springframework.stereotype.Repository;

@Repository("courseDao")
public class CourseDaoImpl implements CourseDao{
    @Profile
    public void readAllCourses() {
        System.out.println("read all the courses from the datasource :");
    }
}
