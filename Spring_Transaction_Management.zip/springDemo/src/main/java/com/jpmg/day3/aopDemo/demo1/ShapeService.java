package com.jpmg.day3.aopDemo.demo1;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ShapeService {

    @Autowired
    private Circle circle;

    @Autowired
    private Triangle triangle;

    public Triangle getTriangle() {
        return triangle;
    }

    public void setTriangle(Triangle triangle) {
        this.triangle = triangle;
    }

    public Circle getCircle() {
        System.out.println("Inside the getCircle method");
        return circle;
    }

    public void setCircle(Circle circle) {
        this.circle = circle;
    }
}
