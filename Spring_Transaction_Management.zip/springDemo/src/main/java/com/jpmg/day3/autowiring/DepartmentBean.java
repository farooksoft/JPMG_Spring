package com.jpmg.day3.autowiring;

public class DepartmentBean {
    String name;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
