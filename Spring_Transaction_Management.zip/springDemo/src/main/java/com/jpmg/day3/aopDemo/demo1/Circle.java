package com.jpmg.day3.aopDemo.demo1;

import org.springframework.stereotype.Component;

@Component
public class Circle {
    private String name = "Oswald";

    @Loggable
    public String getName(){
        System.out.println("Inside the circle");
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
