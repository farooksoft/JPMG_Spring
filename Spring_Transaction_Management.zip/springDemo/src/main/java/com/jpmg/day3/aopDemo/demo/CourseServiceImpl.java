package com.jpmg.day3.aopDemo.demo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

@Service("courseService")
public class CourseServiceImpl implements CourseService{

    @Autowired
    @Qualifier("courseDao")
    private CourseDao dao;

    @Profile
    public void findAllCourses() {
        System.out.println("Started executing the service layer");
        dao.readAllCourses();
        System.out.println("Finished executing the service layer");
    }
}
