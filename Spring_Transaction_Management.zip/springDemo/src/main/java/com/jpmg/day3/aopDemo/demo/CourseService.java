package com.jpmg.day3.aopDemo.demo;

public interface CourseService {
    abstract void findAllCourses();
}
