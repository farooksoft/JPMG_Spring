package com.jpmg.day3.autowiring;

import org.springframework.beans.factory.annotation.Autowired;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Greeter {
    private String greetingFormat;

    @Autowired
    public void configure(GreetingService greetingService, LocalDateTime appServiceTime){
        greetingFormat = String.format("%s. this app is running since: %s%n",greetingService.getGreeting("<NAME>"),
                appServiceTime.format(DateTimeFormatter.ofPattern("YYYY-MMM-dd")));
    }
    public void showGreeting(String name){
        System.out.println(greetingFormat.replaceAll("<NAME>", name));
    }
}
