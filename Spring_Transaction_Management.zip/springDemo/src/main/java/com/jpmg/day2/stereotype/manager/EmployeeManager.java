package com.jpmg.day2.stereotype.manager;

import com.jpmg.day2.stereotype.model.EmployeeDTO;

public interface EmployeeManager {
    public EmployeeDTO createNewEmployee();
}
