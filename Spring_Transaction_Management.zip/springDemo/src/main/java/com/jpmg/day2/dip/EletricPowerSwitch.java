package com.jpmg.day2.dip;

import com.jpmg.day2.dip.ifc.Switch;
import com.jpmg.day2.dip.ifc.Switchable;

public class EletricPowerSwitch implements Switch {
    public Switchable switchable;
    public boolean on;

    public EletricPowerSwitch(Switchable switchable) {
        this.switchable = switchable;
        this.on = on;
    }

    @Override
    public boolean isOn() {
        return this.on;
    }

    @Override
    public void press() {
        boolean checkOn = isOn();
        if(checkOn){
            switchable.turnOff();
            this.on = false;
        }else{
            switchable.turnOn();
            this.on = true;
        }
    }

    public static void main(String[] args) {
        Switchable switchableBulb = new LightBulb();
        Switch bulbPowerSwitch = new EletricPowerSwitch(switchableBulb);
        bulbPowerSwitch.press();
        bulbPowerSwitch.press();

        Switchable switchableFan = new Fan();
        Switch fanPowerSwitch = new EletricPowerSwitch(switchableFan);
        fanPowerSwitch.press();
        fanPowerSwitch.press();
    }
}
