package com.jpmg.day2.stereotype.dao;

import com.jpmg.day2.stereotype.model.EmployeeDTO;

public interface EmployeeDAO {
    public EmployeeDTO createNewEmployee();
}
