package com.jpmg.springDemo;

public class OrderService {
    public String getOrderDetails(String orderId){
        return "Order Details for order ID : "+ orderId;
    }
}
