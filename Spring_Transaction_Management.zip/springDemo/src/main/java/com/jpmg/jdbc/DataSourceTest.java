//package com.jpmg.jdbc;
//
//import javax.sql.DataSource;
//import java.sql.Connection;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//
//public class DataSourceTest {
//    public static void main(String[] args) {
//        testDataSource("mysql");
//        System.out.println("Data Source connectivity");
//    }
//
//    private static void testDataSource(String dbType) {
//        DataSource dataSource = null;
//        if("mysql".equalsIgnoreCase(dbType)){
//            dataSource= MyDataSourceFactory.getMySQLDataSource();
//        }else{
//            System.out.println("Invalid DB");
//            return;
//        }
//        Connection connection = null;
//        Statement statement = null;
//        ResultSet resultSet = null;
//
//        try{
//            connection = dataSource.getConnection();
//            statement = connection.createStatement();
//            resultSet = statement.executeQuery("select id, name, designation, qualification from employee");
//            while (resultSet.next()){
//                System.out.println("Employee ID ="+resultSet.getInt("id")+", Name =" + resultSet.getString("name")+
//                        ",Designation ="+resultSet.getString("designation")+
//                        ", Qualification =" +resultSet.getString("qualification"));
//            }
//
//        }catch (SQLException e){
//            e.printStackTrace();
//        }finally {
//            try{
//                if(resultSet!=null)resultSet.close();
//                if(statement!=null) statement.close();
//                if(connection!=null) connection.close();
//            }catch (SQLException e){
//                e.printStackTrace();
//            }
//        }
//
//
//    }
//}
