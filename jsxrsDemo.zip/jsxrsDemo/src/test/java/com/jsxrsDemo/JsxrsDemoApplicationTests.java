package com.jsxrsDemo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JsxrsDemoApplicationTests {

	@Test
	void contextLoads() {
	}

}
