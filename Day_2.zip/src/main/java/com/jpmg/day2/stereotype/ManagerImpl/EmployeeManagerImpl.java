package com.jpmg.day2.stereotype.ManagerImpl;

import com.jpmg.day2.stereotype.dao.EmployeeDAO;
import com.jpmg.day2.stereotype.manager.EmployeeManager;
import com.jpmg.day2.stereotype.model.EmployeeDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("employeeManager")
public class EmployeeManagerImpl implements EmployeeManager {
    @Autowired
    EmployeeDAO dao;

    @Override
    public EmployeeDTO createNewEmployee() {
     return dao.createNewEmployee();
    }
}
