package com.jpmg.day2.dip;

import com.jpmg.day2.dip.ifc.Switchable;

public class Fan implements Switchable {
    @Override
    public void turnOn() {
        System.out.println("Fan Switched on");
    }

    @Override
    public void turnOff() {
        System.out.println("Fan is switched off");
    }
}
