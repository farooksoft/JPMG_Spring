package com.jpmg.day2.dip;

public interface Messaging {
    public void sendMessage();
}
