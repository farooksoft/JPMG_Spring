package com.jpmg.springDemo;

import org.springframework.beans.factory.annotation.Autowired;

public class ClientBean2 {
    @Autowired
    private ServiceBean serviceBean;

    public void doSomething(){
        System.out.println("From ClientBean2 : ServiceBean" + System.identityHashCode(serviceBean));
    }
}
