package com.jpmg.springDemo.registrationForm.bean;

import com.jpmg.springDemo.registrationForm.service.UserInfo;

import java.util.Map;

public interface UserRegistrationBean {
    public static String KEY_EMAIL = "email";
    public static String KEY_PASSWORD = "password";

    void setUserInfo(UserInfo userInfo);

    Map<String,String> validate();

    void register();
}
