package com.jpmg.springDemo.registrationForm.service;

public interface RegistrationService {
    void register(UserInfo userInfo);
}
