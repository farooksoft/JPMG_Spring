package com.jpmg.springDemo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;

public class FieldBasedDI {
    @Bean
    public OrderService orderService(){
        return new OrderService();
    }

    @Bean
    public OrderServiceClient orderServiceClient(){
        return new OrderServiceClient();
    }

    private static class OrderServiceClient{
        @Autowired
        private OrderService orderService;

        public void showPendingDetails(){
            System.out.println(orderService.getOrderDetails("200"));
        }
    }

    public static void main(String[] args) {
        AnnotationConfigApplicationContext configApplicationContext = new AnnotationConfigApplicationContext(FieldBasedDI.class);
        OrderServiceClient orderServiceClient = configApplicationContext.getBean(OrderServiceClient.class);
        orderServiceClient.showPendingDetails();
    }
}
