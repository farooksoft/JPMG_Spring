package com.jpmg.springDemo;

import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;

@SpringBootApplication
public class SpringDemoApplication {

	public static void main(String[] args) {

		SpringApplication.run(SpringDemoApplication.class, args);
		System.out.println("Hello World");

		// Spring BeanFactory Container
		XmlBeanFactory factory = new XmlBeanFactory(new ClassPathResource("Beans.xml"));
		HelloWorld obj = (HelloWorld) factory.getBean("helloWorld");
		System.out.println(obj.getName() + " " + obj.getMessage());

		//Application context container

		System.out.println("Spring Application context Container");
		System.out.println("File System XML Application Context");

		ApplicationContext context = new FileSystemXmlApplicationContext("D:\\Java Training\\springDemo\\springDemo\\src\\main\\resources\\Beans.xml");
		HelloWorld helloWorld = (HelloWorld) context.getBean("helloWorld");
		System.out.println(helloWorld.getName()+" " + helloWorld.getMessage());

		System.out.println("ClassPathXmlApplicationContext");
		ApplicationContext context1 = new ClassPathXmlApplicationContext("Beans.xml");
		HelloWorld helloWorld1 = (HelloWorld) context1.getBean("helloWorld");
		System.out.println(helloWorld1.getName()+ " "+ helloWorld1.getMessage());
	}

}
