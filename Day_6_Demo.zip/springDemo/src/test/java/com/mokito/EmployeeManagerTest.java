package com.mokito;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;

import java.util.ArrayList;
import java.util.List;

import static org.junit.Assert.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

@RunWith(MockitoJUnitRunner.class)
public class EmployeeManagerTest {

    @InjectMocks
    private EmployeeManager manager;

    @Mock
    private EmployeeDao dao;

    @Mock
    private EmployeeVO employeeVO;

    @Before
    public  void init(){
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void getAllEmployeesTest(){
        List<EmployeeVO> list = new ArrayList<EmployeeVO>();
        EmployeeVO empOne = new EmployeeVO(1,"john", "johny", "john@gmail.com");
        EmployeeVO empTwo = new EmployeeVO(2, "Harry", "Potter", "harry@yahoo.com");
        EmployeeVO empThree = new EmployeeVO(3, "Stuart", "Little", "stuart@gmail.com");

        list.add(empOne);
        list.add(empTwo);
        list.add(empThree);

        when(dao.getEmployeeList()).thenReturn(list);

        List<EmployeeVO> empList = manager.getEmployeeList();

        assertEquals(3, empList.size());
        verify(dao,times(1)).getEmployeeList();

    }

    @Test
    public void getEmployeeByIdTest(){
        when(dao.getEmployeeById(1)).thenReturn(new EmployeeVO(1, "Scooby", "doo", "scooby@gmail.com"));
        EmployeeVO emp = manager.getEmployeeById(1);

        assertEquals("Scooby", emp.getFirstName());
        assertEquals("doo", emp.getLastName());
        assertEquals("scooby@gmail.com", emp.getEmailId());
    }

    @Test
    public void createEmployeeTest(){
        EmployeeVO emp = new EmployeeVO(1, "Scooby", "doo", "scooby@gmail.com");
        manager.addEmployee(emp);
        verify(dao,times(1)).addEmployee(emp);
    }



}