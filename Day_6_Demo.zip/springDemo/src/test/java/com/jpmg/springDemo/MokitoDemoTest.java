package com.jpmg.springDemo;

import org.junit.Test;
import static org.junit.Assert.*;
import static org.mockito.Mockito.*;
import java.util.List;

class MokitoDemoTest {

    @Test
    public void test(){
        List<String> mockList = mock(List.class);
        mockList.add("Fist");
        when(mockList.get(0)).thenReturn("Mockito");
        when(mockList.get(1)).thenReturn("junit");

        assertEquals("Mockito", mockList.get(0));
        assertEquals("junit", mockList.get(1));
    }
}