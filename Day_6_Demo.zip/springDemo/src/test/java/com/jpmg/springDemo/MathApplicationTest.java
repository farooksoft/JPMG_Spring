//package com.mokito;
//
//import org.junit.Assert;
//import org.junit.Before;
//import org.junit.Test;
//import org.junit.runner.RunWith;
//import org.mockito.InjectMocks;
//import org.mockito.Mock;
//import org.mockito.junit.MockitoJUnitRunner;
//
//import static org.mockito.BDDMockito.given;
//
//import static org.mockito.Mockito.*;
//
//@RunWith(MockitoJUnitRunner.class)
//public class MathApplicationTest {
//
//    private MathApplication mathApplication;
//    private CalculatorService calculatorService;
//    @Before
//    public void setUp(){
//        mathApplication = new MathApplication();
//        calculatorService = mock(CalculatorService.class);
//        mathApplication.setCalculatorService(calculatorService);
//    }
//
//    @Test
//    public void testAdd(){
//        //given
//        given(calculatorService.add(20.0,10.0)).willReturn(30.0);
//
//        //when
//        double result = calculatorService.add(20.0,10.0);
//
//        //then
//        Assert.assertEquals(result,30.0,0);
//    }
//
//
//
////    @InjectMocks
////    MathApplication mathApplication = new MathApplication();
////
////    @Mock
////    CalculatorService calculatorService;
////
////    @Test
////    public void testAdd(){
////        when(calculatorService.add(10.0,20.0)).thenReturn(30.00);
////
////        when(calculatorService.subtract(10.0,20.0)).thenReturn(10.00);
////
////        Assert.assertEquals(mathApplication.add(10.0,20.0),30.0,0);
////        Assert.assertEquals(mathApplication.add(10.0,20.0),30.0,0);
////        Assert.assertEquals(mathApplication.add(10.0,20.0),30.0,0);
////        Assert.assertEquals(mathApplication.add(10.0,20.0),30.0,0);
////
////        Assert.assertEquals(mathApplication.subtract(10.0,20.0),10.0,0.0);
////
////
////        verify(calculatorService,atLeastOnce()).subtract(10.0,20.0);
////
////        //verify(calculatorService,times(4)).add(10.0,20.0);
////        verify(calculatorService,atLeast(2)).add(10.0,20.0);
////
////        verify(calculatorService,atMost(4)).add(10.0,20.0);
////
////        verify(calculatorService,never()).multiply(10.0, 20.0);
////
////
////    }
//
//
//}