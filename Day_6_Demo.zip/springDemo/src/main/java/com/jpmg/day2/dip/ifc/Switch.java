package com.jpmg.day2.dip.ifc;

public interface Switch {
    boolean isOn();
    void press();
}
