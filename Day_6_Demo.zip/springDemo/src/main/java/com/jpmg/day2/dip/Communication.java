package com.jpmg.day2.dip;

public class Communication {
    private Messaging messaging;

    public Messaging getMessaging() {
        return messaging;
    }

    // DI via Setter
    public void setMessaging(Messaging messaging) {
        this.messaging = messaging;
    }

    public void communicate(){
        messaging.sendMessage();
    }
}
