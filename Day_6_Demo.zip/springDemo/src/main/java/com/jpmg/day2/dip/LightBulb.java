package com.jpmg.day2.dip;

import com.jpmg.day2.dip.ifc.Switchable;

public class LightBulb implements Switchable {
    @Override
    public void turnOn() {
        System.out.println("Light bulb: Turned On");
    }

    @Override
    public void turnOff() {
        System.out.println("Light bulb: Turned off");
    }
}
