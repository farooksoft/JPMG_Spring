package com.jpmg.jdbc.springJdbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PersonClient {
    @Autowired
    DAO<Person> personDAO;

    public void process(){
        Person person = Person.create("Alice", "Whitely", "1234 xyz street");
        System.out.println("Saving"+ person);
        personDAO.save(person);

        person = Person.create("Scooby","doo", "uvw street");
        System.out.println("Saving"+ person);
        personDAO.save(person);

        List<Person> list = personDAO.loadAll();
        System.out.println("Loaded all"+list);
    }
}
