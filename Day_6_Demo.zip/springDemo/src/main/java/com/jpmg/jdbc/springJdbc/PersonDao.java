package com.jpmg.jdbc.springJdbc;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.jdbc.core.simple.SimpleJdbcInsert;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

@Repository
public class PersonDao implements DAO<Person>{
    @Autowired
    private DataSource dataSource;
    private JdbcTemplate jdbcTemplate;
    private SimpleJdbcInsert simpleJdbcInsert;

    @PostConstruct
    private void postConstruct(){
        jdbcTemplate = new JdbcTemplate(dataSource);
        simpleJdbcInsert = new SimpleJdbcInsert(dataSource).withTableName("person").usingGeneratedKeyColumns("id");
    }
    @Override
    public void save(Person person) {
        SqlParameterSource parameters = new BeanPropertySqlParameterSource(person);
        simpleJdbcInsert.execute(parameters);
    }

    @Override
    public Person load(long id) {
        List<Person> persons = jdbcTemplate.query("select * from person where id = ?",
                new Object[]{id},(resultSet, i) ->{
            return toPerson(resultSet);
        });

        if(persons.size() == 1){
            return persons.get(0);
        }
        return null;

    }

    private Person toPerson(ResultSet resultSet) throws SQLException {
        Person person = new Person();
        person.setId(resultSet.getLong("id"));
        person.setFirstName(resultSet.getString("first_name"));
        person.setLastName(resultSet.getString("last_name"));
        person.setAddress(resultSet.getString("address"));
        return person;
    }

    @Override
    public void delete(long id) {
            jdbcTemplate.update("delete from person where id = ?", id);
    }

    @Override
    public void update(Person person) {
        throw  new UnsupportedOperationException();
    }

    @Override
    public List<Person> loadAll() {
        return jdbcTemplate.query("select * from person", (resultSet, i)-> {
            return toPerson(resultSet);
        });

    }
}
