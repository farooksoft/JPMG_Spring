package com.jpmg.day3.aopDemo.proxy;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
        ApplicationContext context = new ClassPathXmlApplicationContext("Beans.xml");
        Operation e = (Operation) context.getBean("opBean");
        System.out.println("Calling message");
        e.msg();
        System.out.println("calling M");
        e.m();
        System.out.println("Calling K");
        e.k();
    }
}
