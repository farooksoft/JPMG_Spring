package com.jpmg.day3.autowiring;

import javax.annotation.Resource;
import java.util.Arrays;

public class OrderServiceClient {

    @Resource(name = "OrderServiceB")
    private OrderService orderService;

    public void showPendingOrderDetails(){
        for(String orderId : Arrays.asList("100", "250", "350")){
            System.out.println(orderService.getOrderDetails(orderId));
        }
    }
}
