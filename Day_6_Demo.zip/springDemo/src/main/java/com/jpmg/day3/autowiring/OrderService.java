package com.jpmg.day3.autowiring;

public interface OrderService {
    String getOrderDetails(String orderId);
}
