package com.jpmg.day3.autowiring;

public class GreetingService {
    public String getGreeting(String name){
        return "Hi there, Mr." + name;
    }
}
