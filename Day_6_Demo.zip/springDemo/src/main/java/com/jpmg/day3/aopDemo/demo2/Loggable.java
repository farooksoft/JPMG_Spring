package com.jpmg.day3.aopDemo.demo2;

public @interface Loggable {
}
