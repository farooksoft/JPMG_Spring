package com.jpmg.day3.aopDemo.demo2;

import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Aspect;

@Aspect
public class EmployeeAroundAspect {
    public Object employeeAroundAdvice(ProceedingJoinPoint proceedingJoinPoint){
        System.out.println("Before invoking getName() method");
        Object value = null;
        try {
            value = proceedingJoinPoint.proceed();
        }catch (Throwable e){
            e.printStackTrace();
        }
        System.out.println("after invoking getName() mtd. returning value="+value);
        return value;
    }
}
