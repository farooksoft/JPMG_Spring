package com.jpmg.day3.aopDemo.demo;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
    public static void main(String[] args) {
        System.out.println("hello world");

        ApplicationContext applicationContext = new ClassPathXmlApplicationContext("courseApplicationContext.xml");
        CourseService courseService = (CourseService) applicationContext.getBean("courseService");
        courseService.findAllCourses();
    }
}
