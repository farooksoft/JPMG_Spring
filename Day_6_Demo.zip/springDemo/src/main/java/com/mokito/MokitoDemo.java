package com.mokito;

public class MokitoDemo {
}
