package com.orm.demo2;

import java.util.List;

public interface Dao<T> {
    void save(T t);
    T load(Long id);
    void delete(Long id);
    void update (T t);
    List<T> loadAll();
}
