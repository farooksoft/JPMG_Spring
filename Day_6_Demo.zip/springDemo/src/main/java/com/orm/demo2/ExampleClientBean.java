package com.orm.demo2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class ExampleClientBean {
    @Autowired
    PersonService personService;

    public void run(){
        System.out.println("Persisting Person");
        Person person = Person.Create("Alice", "Alice", "wonderland");
        personService.savePerson(person);

        person = Person.Create("Stuart", "Little", "Mexico");
        personService.savePerson(person);

        List<Person> allPersons = personService.getAllPersons();
        System.out.println("Person Loaded:" +allPersons);

        person = personService.getPersonById(2);
        System.out.println("Person Loaded by Id 2:" +person);

        person.setAddress("111 yellow hill");
        personService.updatePerson(person);

        System.out.println("Person deleted by id 3");
        personService.deletePerson(3);

        allPersons = personService.getAllPersons();
        System.out.println("Persons Loaded: "+allPersons);
    }


}
