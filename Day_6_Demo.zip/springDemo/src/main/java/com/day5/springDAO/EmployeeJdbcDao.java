package com.day5.springDAO;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

@Repository
public class EmployeeJdbcDao implements EmployeeDao{
    @Autowired
    private DataSource dataSource;
    private JdbcTemplate jdbcTemplate;

    @PostConstruct
    public void postConstruct(){
        jdbcTemplate = new JdbcTemplate(dataSource);
    }
    @Override
    public void save(Employee employee) {
        String sql = "insert into Employee(name, designation, qualification) values(?,?,?)";
        jdbcTemplate.update(sql,employee.getName(), employee.getDesignation(), employee.getQualification());
    }
}
