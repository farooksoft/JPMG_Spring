package com.day5.springDAO;

public class Employee {
    private Long id;
    private String Name;
    private String Designation;
    private  String Qualification;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }

    public String getDesignation() {
        return Designation;
    }

    public void setDesignation(String designation) {
        Designation = designation;
    }

    public String getQualification() {
        return Qualification;
    }

    public void setQualification(String qualification) {
        Qualification = qualification;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "id=" + id +
                ", Name='" + Name + '\'' +
                ", Designation='" + Designation + '\'' +
                ", Qualification='" + Qualification + '\'' +
                '}';
    }

    public static Employee create (String Name, String Designation, String Qualification){
        Employee employee = new Employee();
        employee.setName(Name);
        employee.setDesignation(Designation);
        employee.setQualification(Qualification);
        return employee;
    }


}
