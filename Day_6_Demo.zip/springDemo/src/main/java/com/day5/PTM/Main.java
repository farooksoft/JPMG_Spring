package com.day5.PTM;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.FileSystemXmlApplicationContext;

import java.util.List;

public class Main {
    public static void main(String[] args) {
        ApplicationContext context = new FileSystemXmlApplicationContext("D:\\Java Training\\springDemo\\springDemo\\src\\main\\resources\\config.beans.xml");

        CustomerDAO customerDAO = context.getBean("CustomerDAOBean", CustomerDAO.class);

        System.out.println("Creating the table");
        customerDAO.createTable();

        System.out.println("Adding the customer Details");
        customerDAO.addCustomer(1, "first Customer", 1000, 23);
        customerDAO.addCustomer(2, "second Customer", 2000, 27);
        customerDAO.addCustomer(3, "Third Customer", 3000, 21);

        System.out.println("getting all the customers from the DB");
        List<Customer_Account> allCustomers = customerDAO.getAllCustomer();
        for(Customer_Account cust:allCustomers){
            System.out.println("CustomerID:" + cust.getId());
            System.out.println("Customer Name: "+ cust.getName());
            System.out.println("customer Balance Amount: " +cust.getAmount());
            System.out.println("Customer's Age: "+ cust.getAge());
        }

        System.out.println("Total Customers: "+customerDAO.countCustomer());

        System.out.println("Deleting a customer with the ID=2");
        customerDAO.deleteCustomer(2);

        System.out.println("new customer Count");
        System.out.println("Total Customers: "+customerDAO.countCustomer());

        System.out.println("customer with id=1 is deposited with 20000");
        customerDAO.depositAmount(1, 20000);

        System.out.println("Customer with ID = 3 made withdraw of 500");
        customerDAO.withdrawAmount(3, 500);

        System.out.println("getting all th customer details");

        List<Customer_Account> allCustomer = customerDAO.getAllCustomer();
        for(Customer_Account cust:allCustomer){
            System.out.println("CustomerID:" + cust.getId());
            System.out.println("Customer Name: "+ cust.getName());
            System.out.println("customer Balance Amount: " +cust.getAmount());
            System.out.println("Customer's Age: "+ cust.getAge());
        }


    }
}
