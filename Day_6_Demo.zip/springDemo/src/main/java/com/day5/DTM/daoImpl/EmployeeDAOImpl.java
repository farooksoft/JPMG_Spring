package com.day5.DTM.daoImpl;

import com.day5.DTM.dao.EmployeeDAO;
import com.day5.DTM.model.Address;
import com.day5.DTM.model.Employees;
import com.day5.springDAO.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.jdbc.core.RowMapper;

import java.sql.ResultSet;
import java.sql.SQLException;

@Repository
public class EmployeeDAOImpl implements EmployeeDAO {

    @Autowired
    private JdbcTemplate jdbcTemplate;


    @Override
    public void insertEmployee(Employees employee) {
        final String INSERT_EMP_QUERY = "insert into employees(id, name, age) values (?,?,?)";
        final String INSERT_ADDR_QUERY= "insert into address(id, address, city) values (?,?,?)";

        jdbcTemplate.update(INSERT_EMP_QUERY, employee.getId(), employee.getName(), employee.getAge());
        System.out.println("Employees record added");

        jdbcTemplate.update(INSERT_ADDR_QUERY, employee.getId(), employee.getAddress().getAddrLine(), employee.getAddress().getCity());
        System.out.println("Employees Address record Added");
    }

    @Override
    public Employees findEmployee(int id) {
        final String SELECT_BY_ID_QUERY = "select emp.id, name, age, address, city from employees emp, address addr where emp.id = addr.id and emp.id =?";

        return this.jdbcTemplate.queryForObject(SELECT_BY_ID_QUERY, new EmployeeMapper(), id);
    }

    private static final class EmployeeMapper implements RowMapper<Employees>{

        @Override
        public Employees mapRow(ResultSet resultSet, int i) throws SQLException {
            Employees employees = new Employees();
            Address address = new Address();
            employees.setId(resultSet.getInt("id"));
            employees.setName(resultSet.getString("name"));
            employees.setAge(resultSet.getInt("age"));
            address.setAddrLine("address");
            address.setCity("city");
            employees.setAddress(address);
            return employees;
        }
    }
}
