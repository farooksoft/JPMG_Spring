package com.jpmg.day3.autowiring;

public class OrderServiceImpl2 implements OrderService{
    @Override
    public String getOrderDetails(String orderId) {
        return "Order details from Impl 2 for the order Id: " +orderId ;
    }
}
