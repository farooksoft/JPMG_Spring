package com.jpmg.day3.aopDemo.demo1;

public @interface Loggable {
}
