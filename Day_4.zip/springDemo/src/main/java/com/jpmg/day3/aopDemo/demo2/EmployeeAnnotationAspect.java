package com.jpmg.day3.aopDemo.demo2;

import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

@Aspect
public class EmployeeAnnotationAspect {

    @Before("@annotation(com.jpmg.day3.aopDemo.demo2.Loggable)")
    public void myAdvice(){
        System.out.println("Executing MyAdvice!!!");
    }
}
