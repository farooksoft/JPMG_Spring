package com.jpmg.day3.aopDemo.demo2;

public class EmployeeService {
    private Employee employee;

    public Employee getEmployee() {
        return this.employee;
    }

    public void setEmployee(Employee employee) {
        this.employee = employee;
    }
}
