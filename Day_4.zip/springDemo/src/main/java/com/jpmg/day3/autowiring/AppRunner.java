package com.jpmg.day3.autowiring;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Configuration
public class AppRunner {
    @Bean
    public GreetingService greetingService(){
        return new GreetingService();
    }

    @Bean
    public LocalDateTime appServiceTime(){
        return LocalDate.of(2021,3,12).atStartOfDay();
    }

    @Bean
    public Greeter greeter(){
        return new Greeter();
    }

    public static void main(String[] args) {
        AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext(AppRunner.class);
        Greeter greeter = context.getBean(Greeter.class);
        greeter.showGreeting("Scobby Doo");
    }
}
