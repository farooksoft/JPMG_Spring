package com.jpmg.day3.aopDemo.demo2;

public class Employee {
    public String name;

    public String getName() {
        return name;
    }

    @Loggable
    public void setName(String name) {
        this.name = name;
    }

    public void throwException(){
        throw new RuntimeException("Dummy Exception");
    }
}
