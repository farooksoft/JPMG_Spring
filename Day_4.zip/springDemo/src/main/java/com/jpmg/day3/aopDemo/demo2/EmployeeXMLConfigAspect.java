package com.jpmg.day3.aopDemo.demo2;

import org.aspectj.lang.ProceedingJoinPoint;

public class EmployeeXMLConfigAspect {

    public Object employeeAroundAdvice(ProceedingJoinPoint proceedingJoinPoint){
        System.out.println("EmployeeXMLConfigAspect:: before invoking getName() method");
        Object value = null;
        try{
            value = proceedingJoinPoint.proceed();
        }catch (Throwable e){
            e.printStackTrace();
        }

        System.out.println("employeeXMLConfigAspect:: After Throwing getName() method.Return value="+value);
        return value;
    }
}
