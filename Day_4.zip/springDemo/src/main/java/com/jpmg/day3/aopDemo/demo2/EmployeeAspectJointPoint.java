package com.jpmg.day3.aopDemo.demo2;

import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;

import java.util.Arrays;

@Aspect
public class EmployeeAspectJointPoint {

    @Before("execution(public void com.jpmg.day3.aopDemo.demo2..set*(*))")
    public void loggingAdvice(JoinPoint joinPoint){
        System.out.println("Before running the loggingAdvice on Method="+joinPoint.toString());

        System.out.println("Argument Passed=" + Arrays.toString(joinPoint.getArgs()));
    }

    @Before("args(name)")
    public void logStringArguments(String name){
        System.out.println("String Argument Passed="+name);
    }
}
