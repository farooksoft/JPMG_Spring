package com.jpmg.day3.autowiring;

public class OrderServiceImpl1 implements OrderService{
    @Override
    public String getOrderDetails(String orderId) {
        return "Order details from Impl 1 for the order Id: " +orderId ;
    }
}
