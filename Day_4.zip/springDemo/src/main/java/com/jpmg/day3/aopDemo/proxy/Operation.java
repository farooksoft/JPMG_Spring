package com.jpmg.day3.aopDemo.proxy;

public class Operation {
    public void msg(){
        System.out.println("Message Method invoked");
    }
    public int m(){
        System.out.println("m method invoked");
        return 2;
    }

    public int k(){
        System.out.println("K Method invoked");
        return 3;
    }
}
