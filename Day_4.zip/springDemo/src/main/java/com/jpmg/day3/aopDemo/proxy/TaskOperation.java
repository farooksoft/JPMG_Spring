package com.jpmg.day3.aopDemo.proxy;

import org.aspectj.lang.JoinPoint;

public class TaskOperation {
    public void myAdvice(JoinPoint joinPoint){
        System.out.println("Additional concern");
    }
}
