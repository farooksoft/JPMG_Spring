package com.jpmg.springDemo;

public class ServiceBean {
}
