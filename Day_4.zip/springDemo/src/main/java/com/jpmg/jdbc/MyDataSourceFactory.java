package com.jpmg.jdbc;

import com.mysql.cj.jdbc.MysqlDataSource;
import org.apache.commons.dbcp2.BasicDataSource;

import javax.sql.DataSource;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

public class MyDataSourceFactory {
    public static DataSource getMySQLDataSource(String dbType){
        Properties properties = new Properties();
        FileInputStream fis = null;
        //MysqlDataSource mysqlDataSource = null;
        BasicDataSource ds = new BasicDataSource();
        try{
            fis = new FileInputStream("D:\\Java Training\\springDemo\\springDemo\\src\\main\\resources\\application.properties");
            properties.load(fis);
        }catch (IOException e){
            e.printStackTrace();
            return null;
        }
        if("mysql".equalsIgnoreCase(dbType)){
            ds.setDriverClassName(properties.getProperty("MYSQL_DB_DRIVER_CLASS"));
            ds.setUrl(properties.getProperty("MYSQL_DB_URL"));
            ds.setUsername(properties.getProperty("MYSQL_DB_USERNAME"));
            ds.setPassword(properties.getProperty("MYSQL_DB_PASSWORD"));
        }else {
            return null;
        }
        return ds;
    }
}
