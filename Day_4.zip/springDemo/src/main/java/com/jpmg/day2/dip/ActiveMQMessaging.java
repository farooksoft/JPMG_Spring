package com.jpmg.day2.dip;

public class ActiveMQMessaging implements Messaging{
    @Override
    public void sendMessage() {
        System.out.println("Sending message service");
    }
}
