package com.jpmg.day2.stereotype.daoImpl;

import com.jpmg.day2.stereotype.dao.EmployeeDAO;
import com.jpmg.day2.stereotype.model.EmployeeDTO;
import org.springframework.stereotype.Repository;

@Repository("employeeDao")
public class EmployeeDAOImpl implements EmployeeDAO {
    @Override
    public EmployeeDTO createNewEmployee() {
        EmployeeDTO e = new EmployeeDTO();
        e.setId(1);
        e.setFirstName("Scooby");
        e.setLastName("Doo");
        return e;
    }
}
