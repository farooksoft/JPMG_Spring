package com.jpmg.day2.dip.ifc;

public interface Switchable {
    void turnOn();
    void turnOff();
}
