package com.sbjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SbjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
