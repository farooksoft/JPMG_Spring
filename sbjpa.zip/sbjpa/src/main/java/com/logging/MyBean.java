package com.logging;

import org.springframework.stereotype.Component;

import java.util.logging.Logger;

@Component
public class MyBean {
    private static final Logger logger = Logger.getLogger(MyBean.class.getName());

    public void doSomething(){
        System.out.println(" in do something mtd");
        logger.info("Some message");
    }
}
