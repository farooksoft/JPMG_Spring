package com.hateoas.dao;

import com.hateoas.model.Employee;

import java.util.List;
import java.util.Optional;

public interface EmployeeDao {
    public Optional<Employee> getEmployeeByIdFromDb(int eid);
    public List<Employee> getAllEmployeeFromDb();
}
