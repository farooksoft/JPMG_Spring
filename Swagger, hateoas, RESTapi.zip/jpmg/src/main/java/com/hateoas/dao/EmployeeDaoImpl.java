package com.hateoas.dao;

import com.github.javafaker.Faker;
import com.hateoas.model.Employee;
import org.springframework.stereotype.Repository;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
@Repository
public class EmployeeDaoImpl implements EmployeeDao{

    static List<Employee> employees;
    static {
        employees = new ArrayList<>();
        Faker faker = new Faker();

        for (int i = 1; i<=10;i++){
            Employee employee = new Employee();
            employee.setId(i);
            employee.setName(faker.name().fullName());
            employee.setMobile(faker.phoneNumber().cellPhone());
            employee.setAddress(faker.address().fullAddress());
            employees.add(employee);
        }
    }

    @Override
    public Optional<Employee> getEmployeeByIdFromDb(int eid) {
        return employees.stream().filter((employee) -> employee.getId() == eid).findFirst();
    }

    @Override
    public List<Employee> getAllEmployeeFromDb() {
        return employees;
    }
}
