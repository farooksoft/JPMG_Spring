package com.hateoas.util;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import com.hateoas.controller.EmployeeController;
import com.hateoas.model.Employee;
import org.springframework.hateoas.EntityModel;

public class Helper {

    public static EntityModel<Employee> getEmployeeResource(Employee employee){
        EntityModel<Employee> resource = new EntityModel<>(employee);
        resource.add(linkTo(methodOn(EmployeeController.class).getEmployeeById(employee.getId())).withRel("_self"));
        return resource;
    }
}
