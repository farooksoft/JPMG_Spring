package com.hateoas.service;

import com.hateoas.dao.EmployeeDao;
import com.hateoas.model.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
@Service
public class EmployeeServiceImpl implements EmployeeService{
    @Autowired
    EmployeeDao employeeDao;

    @Override
    public Optional<Employee> getEmployeeByIdFromService(int eid) {
        return employeeDao.getEmployeeByIdFromDb(eid);
    }

    @Override
    public List<Employee> getAllEmployeesFromService() {
        return employeeDao.getAllEmployeeFromDb();
    }
}
