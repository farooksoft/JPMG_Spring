package com.hateoas.service;

import com.hateoas.model.Employee;

import java.util.List;
import java.util.Optional;

public interface EmployeeService {
    public Optional<Employee> getEmployeeByIdFromService(int eid);

    public List<Employee> getAllEmployeesFromService();
}
