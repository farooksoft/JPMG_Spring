package com.hateoas.controller;

import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.linkTo;
import static org.springframework.hateoas.server.mvc.WebMvcLinkBuilder.methodOn;

import com.hateoas.model.Employee;
import com.hateoas.service.EmployeeService;
import com.hateoas.util.Helper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.hateoas.EntityModel;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(value = "/employee")
public class EmployeeController {

    @Autowired
    EmployeeService employeeService;

    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @GetMapping(value = "/get/{id}")
    public EntityModel<Employee> getEmployeeById(@PathVariable(name = "id") int eid){
        Employee employee = employeeService.getEmployeeByIdFromService(eid).get();
        logger.info("Employee byId() found: " +employee.toString());
        EntityModel<Employee> employeeEntityModel = new EntityModel<>(employee);
        employeeEntityModel.add(linkTo(methodOn(EmployeeController.class).getEmployeeById(eid)).withRel("_self"));
        return employeeEntityModel;
    }

    @GetMapping(value = "/getAll")
    public List<EntityModel<Employee>> getAllEmployees(){
        logger.info("Employees all() invoked");

        List<Employee> employees = employeeService.getAllEmployeesFromService();
        List<EntityModel<Employee>> entityModelList = new ArrayList<>();

        for (Employee employee : employees){
            entityModelList.add(Helper.getEmployeeResource(employee));
        }
        logger.info("Employees all() found"+entityModelList.size());
        return entityModelList;
    }
}
