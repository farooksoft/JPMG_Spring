package com.jpmg.jpa.controller;

import com.jpmg.jpa.model.Data;
import com.jpmg.jpa.repository.DataRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@CrossOrigin(origins = "http://localhost:8081")
@RestController
@RequestMapping("/api")
public class DataController {
    @Autowired
    DataRepository dataRepository;

    @GetMapping("/data")
    public ResponseEntity<List<Data>> getAlldata(@RequestParam(required = false) String title) {
        try {
            List<Data> data = new ArrayList<Data>();

            if (title == null)
                dataRepository.findAll().forEach(data::add);
            else
                dataRepository.findByTitleContaining(title).forEach(data::add);

            if (data.isEmpty()) {
                return new ResponseEntity<>(HttpStatus.NO_CONTENT);
            }
            return new ResponseEntity<>(data, HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @GetMapping("/data/{id}")
    public ResponseEntity<Data> getDataById(@PathVariable("id") long id) {
        Optional<Data> data = dataRepository.findById(id);
        if (data.isPresent()) {
            return new ResponseEntity<>(data.get(), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @PostMapping("/data")
    public ResponseEntity<Data> createData(@RequestBody Data data) {
        try {
            Data _data = dataRepository.save(new Data(data.getTitle(), data.getDescription(), false));
            return new ResponseEntity<>(_data, HttpStatus.CREATED);
        } catch (Exception e) {
            return new ResponseEntity<>(null, HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @PutMapping("/data/{id}")
    public ResponseEntity<Data> updateData(@PathVariable("id") long id, @RequestBody Data data) {
        Optional<Data> data1 = dataRepository.findById(id);

        if (data1.isPresent()) {
            Data _data = data1.get();
            _data.setTitle(data.getTitle());
            _data.setDescription(data.getDescription());
            _data.setPublished(data.isPublished());
            return new ResponseEntity<>(dataRepository.save(_data), HttpStatus.OK);
        } else {
            return new ResponseEntity<>(HttpStatus.NOT_FOUND);
        }
    }

    @DeleteMapping("/data/{id}")
    public ResponseEntity<HttpStatus> deleteData(@PathVariable("id") long id) {
        try {
            dataRepository.deleteById(id);
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }

    @DeleteMapping("/data")
    public ResponseEntity<HttpStatus> deleteAllData() {
        try {
            dataRepository.deleteAll();
            return new ResponseEntity<>(HttpStatus.NO_CONTENT);
        } catch (Exception e) {
            return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
        }
    }
}
