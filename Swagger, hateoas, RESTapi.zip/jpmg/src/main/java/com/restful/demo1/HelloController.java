package com.restful.demo1;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class HelloController {
    @RequestMapping("/hello")
    public String hello(){
        return "Hello guys, welcome to RESTFUL API demo!!!";
    }

    @RequestMapping("/cya")
    public String cya(){
        return "Bye for now, take care.";
    }
}
