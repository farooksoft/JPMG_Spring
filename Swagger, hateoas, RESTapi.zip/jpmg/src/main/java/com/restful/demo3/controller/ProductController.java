package com.restful.demo3.controller;

import com.restful.demo3.model.Product;
import com.restful.demo3.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class ProductController {

    @Autowired
    ProductService productService;

    @GetMapping(value = "/product")
    public List<Product> getProduct(){
        List<Product> products = productService.findAll();
        return products;
    }
}
