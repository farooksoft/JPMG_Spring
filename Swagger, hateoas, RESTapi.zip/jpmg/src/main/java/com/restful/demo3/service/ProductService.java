package com.restful.demo3.service;

import com.restful.demo3.model.Product;

import java.util.List;

public interface ProductService {
    List<Product> findAll();
}
