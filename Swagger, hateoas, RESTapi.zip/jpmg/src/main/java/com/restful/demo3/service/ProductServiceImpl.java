package com.restful.demo3.service;

import com.restful.demo3.model.Product;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
@Service
public class ProductServiceImpl implements ProductService{
    @Override
    public List<Product> findAll() {
        ArrayList<Product> products = new ArrayList<>();
        products.add(new Product(100, "Mobile", "CLK98123", 9000.00, 6));
        products.add(new Product(200, "Smart TV", "DAS4345", 59000.00, 16));
        products.add(new Product(300, "Laptop", "DELL3344", 79000.00, 2));
        return products;
    }
}
