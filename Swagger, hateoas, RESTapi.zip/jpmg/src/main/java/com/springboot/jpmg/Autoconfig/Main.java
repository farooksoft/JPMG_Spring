package com.springboot.jpmg.Autoconfig;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.AutoConfigurationPackages;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.jmx.JmxAutoConfiguration;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

import java.util.List;

//@ComponentScan
@EnableAutoConfiguration(exclude = {JmxAutoConfiguration.class})
//@SpringBootApplication
public class Main {
//    @Bean
//    public MyBean myBean(){
//        return new MyBean();
//    }
//
//    @Bean
//    public MyController controller(){
//        return new MyController();
//    }

    public static void main(String[] args) {
        SpringApplication application = new SpringApplication(Main.class);
        application.setBannerMode(Banner.Mode.OFF);
        application.setLogStartupInfo(false);
        ConfigurableApplicationContext c = application.run(args);
        List<String> packages = AutoConfigurationPackages.get(c);
        System.out.println("Packages:" + packages);
        //SpringApplication.run(Main.class,args);
    }
}
