package com.springboot.jpmg.profile.service;

public interface WeatherService {
    String forecast();
}
