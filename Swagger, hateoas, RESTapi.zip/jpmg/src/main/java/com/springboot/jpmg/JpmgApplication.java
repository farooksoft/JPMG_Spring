package com.springboot.jpmg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
public class JpmgApplication {

	public static void main(String[] args) {
		SpringApplication.run(JpmgApplication.class, args);
	}

	@RestController
	private static class TheController{
		@RequestMapping("/")
		public String handle(){
			return "hello world";
		}
	}

}
