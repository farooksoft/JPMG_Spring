package com.springboot.jpmg.Autoconfig;

import org.springframework.stereotype.Component;

@Component
public class MyBean {
    public String getMessage(){
        return "a Message from My bean";
    }
}
